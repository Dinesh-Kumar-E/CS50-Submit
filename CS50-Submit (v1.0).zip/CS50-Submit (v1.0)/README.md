# CS50-Submit
This is an automated python script to submit CS50 projects provided by Harvard University.
